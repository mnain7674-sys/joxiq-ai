# JOXIQ AI — Unified Automation Backend

All 100 automation features in **one server**, ready to sit behind your
Google AI Studio frontend.

## Why a separate backend?

Google AI Studio apps are typically frontend-only (React calling the Gemini
API directly from the browser) — there's no server to persist data, run
scheduled jobs, or track usage across sessions. This backend fills that gap.
Your AI Studio frontend keeps doing what it does now (calling Gemini for
chat); this server handles everything *around* that — saving chats, tracking
usage, reminders, security, etc.

## 1. Run it locally first

```bash
npm install
npm start
```

Server starts on `http://localhost:3000`. Test it:
```bash
curl http://localhost:3000/health
```

## 2. Deploy it somewhere it can stay running

Pick one (all have free tiers):
- **Render** (render.com) — easiest, connect your GitHub repo, auto-deploys
- **Railway** (railway.app) — similar, one-click deploy
- **Fly.io** — good free tier for small Node apps

Steps (Render example):
1. Push this folder to a GitHub repo
2. On Render: New → Web Service → connect the repo
3. Build command: `npm install`
4. Start command: `npm start`
5. Deploy — you'll get a URL like `https://joxiq-backend.onrender.com`

## 3. Connect your Google AI Studio frontend to it

In your frontend code, call this backend alongside your existing Gemini calls:

```javascript
const BACKEND_URL = "https://joxiq-backend.onrender.com"; // your deployed URL

// Example: save a chat message
await fetch(`${BACKEND_URL}/api/automation/chat/${userId}/${conversationId}/messages`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ role: "user", content: userMessage }),
});
```

CORS is already enabled in `app.js` (`app.use(cors({ origin: "*" }))`) so your
frontend's domain can call this backend. For production, tighten this to your
actual frontend URL instead of `"*"`.

## 4. Features that need your existing Gemini call

Six generator features (Notes, Summary, Quiz, Exam, Flashcards, Mind Map) use
an injected `generateFn` — this should be the *same* Gemini call your AI
Studio app already makes. Example:

```javascript
async function myGeminiCall(prompt) {
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
  });
  const data = await res.json();
  return data.candidates[0].content.parts[0].text;
}

const { generateSummary } = require("./services/contentGenerationService");
const result = await generateSummary(sourceText, myGeminiCall);
```

## 5. Data storage

Everything currently saves to JSON files in `/data` (auto-created) — fine for
testing, but on most free hosting tiers the filesystem resets on redeploy.
For real users, swap `src/utils/db.js` for a real database (MongoDB Atlas has
a free tier, or Render/Railway both offer free Postgres). Every service only
calls `read()`/`write()` from that one file, so nothing else needs to change.

## 6. Feature reference

All feature-to-file mapping is documented in comments at the top of each
service file under `src/services/`. Full route list is in
`src/routes/phase1Routes.js` (features 1-50) and `src/routes/phase2Routes.js`
(features 51-100).

## Start small

Don't wire all 100 endpoints into your frontend at once. Start with 2-3
(chat save, theme detection) — confirm they work end-to-end — then add more.
