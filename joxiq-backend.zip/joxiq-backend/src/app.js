const express = require("express");
const cors = require("cors");
const automationRoutes = require("./routes/index");
const maintenance = require("./services/maintenanceService");
const systemOps = require("./services/systemOpsService");

const app = express();

// Allow your Google AI Studio frontend (hosted on a different domain) to call this API.
// For production, replace "*" with your actual frontend URL for better security,
// e.g. origin: "https://your-app.vercel.app"
app.use(cors({ origin: "*" }));
app.use(express.json());

app.get("/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

// #97 Auto Maintenance Mode — blocks non-health requests when enabled
app.use((req, res, next) => {
  const state = systemOps.getMaintenanceMode();
  if (state.enabled && req.path !== "/health") {
    return res.status(503).json({ error: state.message });
  }
  next();
});

app.use("/api/automation", automationRoutes);

function setupScheduledJobs() {
  const ONE_HOUR = 60 * 60 * 1000;
  setInterval(() => {
    const result = maintenance.cleanExpiredCache();
    if (result.removed > 0) console.log(`[cache-cleaner] removed ${result.removed} expired entries`);
  }, ONE_HOUR);
}

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`JOXIQ AI Automation Backend running on http://localhost:${PORT}`);
    setupScheduledJobs();
  });
}

module.exports = app;
