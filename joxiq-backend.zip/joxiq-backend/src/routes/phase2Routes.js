const express = require("express");
const router = express.Router();

const workflow = require("../services/workflowService");
const docOrganizer = require("../services/documentOrganizerService");
const docAnalysis = require("../services/documentAnalysisService");
const contentGen = require("../services/contentGenerationService");
const studyTools = require("../services/studyToolsService");
const planningTracking = require("../services/planningTrackingService");
const achievement = require("../services/achievementService");
const dashboard = require("../services/dashboardService");
const searchIndex = require("../services/searchIndexService");
const infraMonitor = require("../services/infraMonitorService");
const databaseOps = require("../services/databaseOpsService");
const security = require("../services/securityService");
const linkVersion = require("../services/linkVersionService");
const featureFeedback = require("../services/featureFeedbackService");
const analyticsDashboard = require("../services/analyticsDashboardService");
const modelOps = require("../services/modelOpsService");
const systemOps = require("../services/systemOpsService");
const controlCenter = require("../services/controlCenterService");

const ok = (fn) => (req, res) => {
  try { res.json(fn(req)); } catch (e) { res.status(400).json({ error: e.message }); }
};
const okAsync = (fn) => async (req, res) => {
  try { res.json(await fn(req)); } catch (e) { res.status(400).json({ error: e.message }); }
};

// #51, #52 Workflow
router.post("/workflows/:userId", ok((req) => workflow.saveWorkflow(req.params.userId, req.body.name, req.body.steps)));
router.get("/workflows/:userId/:name", ok((req) => workflow.getWorkflow(req.params.userId, req.params.name)));

// #53, #58, #59, #60 Document organization
router.post("/documents/:userId/organize", ok((req) => docOrganizer.organizeDocument(req.params.userId, req.body.fileName, req.body.sizeBytes)));
router.get("/documents/:userId", ok((req) => docOrganizer.getDocumentsByCategory(req.params.userId, req.query.category)));
router.post("/files/sort", ok((req) => docOrganizer.sortFiles(req.body.fileNames)));
router.post("/files/rename", ok((req) => ({ newName: docOrganizer.renameFile(req.body.originalName, req.body.options) })));
router.post("/screenshots/organize", ok((req) => docOrganizer.organizeScreenshots(req.body.files)));

// #54, #55, #56, #57 Document analysis (free open-source libs — needs npm install)
router.post("/documents/analyze-pdf", okAsync(async (req) => {
  throw new Error("This endpoint expects a raw file upload; wire multer + call documentAnalysisService.analyzePdf(buffer) — see code comments");
}));

// #61, #62 Content generation (uses your existing AI provider)
router.post("/notes/generate", okAsync(async () => {
  throw new Error("Wire generateFn into contentGenerationService.generateNotes() using your existing Gemini/ChatGPT/Claude call");
}));

// #67, #68, #69 Planning & tracking
router.post("/study-plan/:userId", ok((req) => planningTracking.buildStudyPlan(req.params.userId, req.body.topics, req.body.options)));
router.post("/habits/:userId/:habitId/check-in", ok((req) => planningTracking.logHabitCheckIn(req.params.userId, req.params.habitId)));
router.post("/progress/:userId", ok((req) => planningTracking.recordProgress(req.params.userId, req.body.unitId, req.body.score)));
router.get("/progress/:userId", ok((req) => planningTracking.getProgressSummary(req.params.userId)));

// #70, #71, #72 Achievement
router.get("/achievements/:userId", ok((req) => achievement.evaluateAchievements(req.params.userId)));
router.post("/recommend-topics/:userId", ok((req) => achievement.recommendNextTopics(req.params.userId, req.body.allTopics)));

// #73, #74 Dashboard
router.post("/dashboard/:userId/personalize", ok((req) => ({ widgetOrder: dashboard.personalizeDashboard(req.params.userId, req.body.widgetIds) })));
router.post("/widgets/:userId/:widgetId", ok((req) => dashboard.setWidgetConfig(req.params.userId, req.params.widgetId, req.body)));
router.get("/widgets/:userId", ok((req) => dashboard.getWidgetConfigs(req.params.userId)));

// #75, #76 Search index & validation
router.post("/index/:collection/build", ok((req) => searchIndex.buildIndex(req.params.collection, req.body.textField)));
router.get("/index/:collection/search", ok((req) => searchIndex.searchIndex(req.params.collection, req.query.q || "")));
router.post("/validate", ok((req) => searchIndex.validate(req.body.record, req.body.schema)));

// #77, #78 Infra monitoring
router.post("/api-usage/:apiKey/log", ok((req) => { infraMonitor.recordApiCall(req.params.apiKey, req.body.endpoint); return { recorded: true }; }));
router.get("/api-usage/:apiKey", ok((req) => ({ count: infraMonitor.getApiUsage(req.params.apiKey, Number(req.query.sinceMs) || 3600000) })));
router.post("/health/check", okAsync(async (req) => infraMonitor.checkServerStatus(req.body.name, req.body.url)));
router.get("/health/:name/history", ok((req) => infraMonitor.getHealthHistory(req.params.name)));

// #79, #80 Database ops
router.post("/db/:collection/clean", ok((req) => databaseOps.cleanCollection(req.params.collection, req.body)));
router.post("/db/backup", ok(() => databaseOps.backupDatabase()));
router.get("/db/backups", ok(() => databaseOps.listBackups()));

// #81, #82, #83, #84 Security
router.post("/security/scan", ok((req) => security.scanForThreats(req.body.input)));
router.post("/security/:userId/login-attempt", ok((req) => { security.recordLoginAttempt(req.params.userId, req.body.success); return { recorded: true }; }));
router.get("/security/:userId/lockout-status", ok((req) => security.isLockedOut(req.params.userId)));
router.post("/content/filter", ok((req) => security.filterContent(req.body.userId, req.body.text)));

// #85, #86, #87 Links & versions
router.post("/links/check", okAsync(async (req) => ({ results: await linkVersion.checkLinks(req.body.urls) })));
router.get("/version/compare", ok((req) => ({ result: linkVersion.compareVersions(req.query.v1, req.query.v2) })));
router.get("/version/check-update", ok((req) => linkVersion.checkForUpdate(req.query.current, req.query.latest)));

// #88, #89 Flags & feedback
router.post("/flags/:name", ok((req) => featureFeedback.setFlag(req.params.name, req.body.enabled, req.body.rolloutPercent)));
router.get("/flags/:name/check", ok((req) => ({ enabled: featureFeedback.isFlagEnabled(req.params.name, req.query.userId) })));
router.post("/feedback/:userId", ok((req) => featureFeedback.collectFeedback(req.params.userId, req.body.text)));
router.get("/feedback/trends", ok(() => featureFeedback.getFeedbackTrends()));

// #90, #91 Analytics
router.get("/analytics/dashboard", ok(() => analyticsDashboard.getAnalyticsDashboard()));
router.post("/analytics/inactive-users", ok((req) => analyticsDashboard.getInactiveUsers(req.body.allUserIds, req.body.inactiveDays)));

// #92, #93, #94, #95 Model ops & resources
router.get("/model/select", ok((req) => modelOps.selectModel(req.query.taskType)));
router.post("/tokens/:userId/log", ok((req) => modelOps.logTokenUsage(req.params.userId, req.body)));
router.get("/tokens/:userId/summary", ok((req) => modelOps.getTokenUsageSummary(req.params.userId)));
router.post("/latency/:endpoint/log", ok((req) => { modelOps.recordEndpointLatency(req.params.endpoint, req.body.latencyMs); return { recorded: true }; }));
router.get("/latency/slow", ok((req) => modelOps.getSlowEndpoints(Number(req.query.thresholdMs) || 500)));
router.get("/quota/:userId", ok((req) => modelOps.checkQuota(req.params.userId, Number(req.query.limit) || 100000)));

// #96, #97, #98 System ops
router.get("/system/diagnostics", ok(() => systemOps.runDiagnostics()));
router.post("/system/maintenance-mode", ok((req) => systemOps.setMaintenanceMode(req.body.enabled, req.body.message)));
router.get("/system/maintenance-mode", ok(() => systemOps.getMaintenanceMode()));
router.post("/system/recover", ok(() => systemOps.recoverFromLatestBackup()));

// #99, #100 Control center
router.get("/automation-center", ok(() => controlCenter.getAutomationCenterStatus()));
router.get("/control-center", ok(() => controlCenter.getControlCenterDashboard()));

module.exports = router;
