const express = require("express");
const router = express.Router();

const chatPersistence = require("../services/chatPersistenceService");
const chatMeta = require("../services/chatMetaService");
const uiPreference = require("../services/uiPreferenceService");
const maintenance = require("../services/maintenanceService");
const diagnostics = require("../services/diagnosticsService");
const usageStats = require("../services/usageStatsService");
const reminder = require("../services/reminderService");
const suggestion = require("../services/suggestionService");
const chatOrganization = require("../services/chatOrganizationService");
const connectivity = require("../services/connectivityService");
const formatting = require("../services/formattingService");
const textQuality = require("../services/textQualityService");
const accessibility = require("../services/accessibilityService");

const ok = (fn) => (req, res) => {
  try { res.json(fn(req)); } catch (e) { res.status(400).json({ error: e.message }); }
};
const okAsync = (fn) => async (req, res) => {
  try { res.json(await fn(req)); } catch (e) { res.status(400).json({ error: e.message }); }
};

// #1, #2, #6, #7, #11 Chat persistence
router.post("/chat/:userId/:conversationId/messages", ok((req) => chatPersistence.saveMessage(req.params.userId, req.params.conversationId, req.body)));
router.get("/chat/:userId/:conversationId", ok((req) => chatPersistence.getConversation(req.params.userId, req.params.conversationId)));
router.post("/chat/:userId/:conversationId/draft", ok((req) => { chatPersistence.saveDraft(req.params.userId, req.params.conversationId, req.body.draftText); return { saved: true }; }));
router.get("/chat/:userId/:conversationId/draft", ok((req) => chatPersistence.recoverDraft(req.params.userId, req.params.conversationId)));
router.post("/chat/:userId/backup", ok((req) => chatPersistence.backupChats(req.params.userId)));
router.post("/chat/:userId/restore", ok((req) => chatPersistence.restoreChats(req.params.userId)));
router.post("/session/:userId", ok((req) => { chatPersistence.saveSessionState(req.params.userId, req.body.state); return { saved: true }; }));
router.get("/session/:userId", ok((req) => chatPersistence.restoreSessionState(req.params.userId)));

// #3, #4, #5 Chat meta
router.post("/chat/title", ok((req) => ({ title: chatMeta.generateTitle(req.body.firstMessage) })));
router.post("/prompts/:userId/log", ok((req) => { chatMeta.logPrompt(req.params.userId, req.body.promptText); return { logged: true }; }));
router.get("/prompts/:userId/history", ok((req) => chatMeta.getPromptHistory(req.params.userId, Number(req.query.limit) || 50)));
router.post("/chat/:userId/:conversationId/favorite", ok((req) => chatMeta.toggleFavorite(req.params.userId, req.params.conversationId)));
router.get("/favorites/:userId", ok((req) => chatMeta.getFavorites(req.params.userId)));

// #8, #9, #10, #31, #32 UI preferences
router.get("/theme/detect", ok((req) => ({ theme: uiPreference.detectTheme(req.query.hour && Number(req.query.hour)) })));
router.post("/language/detect", ok((req) => ({ language: uiPreference.detectLanguage(req.body.text) })));
router.get("/greeting/:userName?", ok((req) => ({ greeting: uiPreference.getGreeting(req.params.userName) })));
router.post("/preferences/:userId", ok((req) => uiPreference.setPreference(req.params.userId, req.body.key, req.body.value)));
router.get("/preferences/:userId", ok((req) => uiPreference.getPreferences(req.params.userId)));
router.post("/preferences/:userId/backup", ok((req) => uiPreference.backupSettings(req.params.userId)));
router.post("/preferences/:userId/restore", ok((req) => uiPreference.restoreSettings(req.params.userId)));

// #12, #13, #38 Maintenance
router.post("/cache/clean", ok(() => maintenance.cleanExpiredCache()));
router.get("/storage/report", ok(() => maintenance.getStorageReport()));
router.post("/storage/optimize/:collection", ok((req) => maintenance.optimizeCollection(req.params.collection, Number(req.query.keep) || 1000)));
router.post("/memory/cleanup/:collection", ok((req) => maintenance.cleanupStaleRecords(req.params.collection, req.body.dateField, Number(req.body.maxAgeDays) || 30)));

// #14, #15, #37, #39 Diagnostics
router.post("/diagnostics/error", ok((req) => diagnostics.logError(req.body.context, { message: req.body.message, stack: req.body.stack })));
router.post("/diagnostics/:userId/bug-report", ok((req) => diagnostics.submitBugReport(req.params.userId, req.body)));
router.post("/diagnostics/load-time", ok((req) => { diagnostics.recordLoadTime(req.body.screenName, req.body.loadMs); return { recorded: true }; }));
router.get("/diagnostics/slow-screens", ok((req) => diagnostics.getSlowScreens(Number(req.query.thresholdMs) || 1000)));
router.post("/diagnostics/performance", ok((req) => { diagnostics.recordPerformanceMetric(req.body.metric, req.body.value); return { recorded: true }; }));
router.get("/diagnostics/performance", ok((req) => diagnostics.getPerformanceSummary(req.query.metric)));

// #16, #17, #18, #19 Usage stats
router.post("/usage/:userId/track", ok((req) => { usageStats.trackUsage(req.params.userId, req.body.eventName, req.body.metadata); return { tracked: true }; }));
router.get("/usage/:userId/daily", ok((req) => usageStats.getDailyStats(req.params.userId, req.query.date)));
router.get("/usage/:userId/weekly", ok((req) => usageStats.getWeeklyStats(req.params.userId, req.query.weekStart)));
router.get("/usage/:userId/monthly", ok((req) => usageStats.getMonthlyStats(req.params.userId, req.query.year && Number(req.query.year), req.query.month && Number(req.query.month))));

// #20, #21, #22, #23 Reminders
router.post("/reminders/:userId/schedule", ok((req) => reminder.scheduleNotification(req.params.userId, req.body)));
router.get("/reminders/due", ok(() => reminder.getDueNotifications()));
router.post("/reminders/:userId/goal", ok((req) => reminder.setGoalReminder(req.params.userId, req.body.goalName, Number(req.body.cadenceHours) || 24)));
router.post("/reminders/:userId/study", ok((req) => reminder.setStudyReminder(req.params.userId, req.body.topic, req.body.sendAt)));
router.post("/reminders/:userId/task", ok((req) => reminder.setTaskReminder(req.params.userId, req.body.taskName, req.body.dueAt)));

// #24, #25, #29 Suggestions
router.get("/suggestions/:userId/next-actions", ok((req) => suggestion.suggestNextActions(req.params.userId)));
router.get("/suggestions/prompts", ok((req) => suggestion.suggestPrompts(req.query.topic)));
router.post("/suggestions/:userId/search-record", ok((req) => { suggestion.recordSearch(req.params.userId, req.body.query); return { recorded: true }; }));
router.get("/suggestions/:userId/search", ok((req) => suggestion.getSearchSuggestions(req.params.userId, req.query.q || "")));

// #26, #27, #28, #30 Chat organization
router.post("/chat/categorize", ok((req) => ({ category: chatOrganization.categorizeConversation(req.body.text) })));
router.post("/chat/:userId/folder", ok((req) => chatOrganization.assignToFolder(req.params.userId, req.body.conversationId, req.body.category)));
router.get("/chat/:userId/folders", ok((req) => chatOrganization.getFolders(req.params.userId)));
router.post("/chat/duplicates", ok((req) => chatOrganization.findDuplicates(req.body.conversations)));
router.post("/activity/:userId/log", ok((req) => { chatOrganization.logActivity(req.params.userId, req.body.action, req.body.details); return { logged: true }; }));
router.get("/activity/:userId", ok((req) => chatOrganization.getRecentActivity(req.params.userId, Number(req.query.limit) || 20)));

// #33, #34, #35, #36 Connectivity
router.post("/device/detect", ok((req) => connectivity.detectDevice(req.body.userAgent)));
router.post("/connectivity/:userId/ping", ok((req) => { connectivity.recordConnectivityPing(req.params.userId, req.body.isOnline); return { recorded: true }; }));
router.get("/connectivity/:userId", ok((req) => connectivity.getConnectivityStatus(req.params.userId)));
router.post("/sync-queue/:userId", ok((req) => connectivity.queueOfflineAction(req.params.userId, req.body.action, req.body.payload)));
router.get("/sync-queue/:userId", ok((req) => connectivity.getPendingSyncItems(req.params.userId)));
router.post("/sync-queue/:itemId/synced", ok((req) => connectivity.markSynced(req.params.itemId)));

// #40, #41, #42 Formatting
router.post("/format/response", ok((req) => ({ text: formatting.formatResponse(req.body.text) })));
router.post("/format/markdown", ok((req) => ({ text: formatting.formatMarkdown(req.body.text) })));
router.post("/format/code", ok((req) => ({ code: formatting.formatCode(req.body.code, req.body.indentSize) })));

// #43, #44, #45, #46 Text quality
router.post("/text/correct", ok((req) => ({ text: textQuality.correctText(req.body.text) })));
router.post("/text/spelling-check", ok((req) => ({ issues: textQuality.checkSpelling(req.body.text) })));
router.post("/text/grammar-check", ok((req) => ({ issues: textQuality.checkGrammar(req.body.text) })));
router.post("/text/translate", okAsync(async (req) => textQuality.translate(req.body.text, req.body.fromLang, req.body.toLang)));

// #47, #48, #49, #50 Accessibility
router.post("/voice/detect-activity", ok((req) => accessibility.detectVoiceActivity(req.body.audioEnergyLevels)));
router.post("/accessibility/settings", ok((req) => accessibility.getAccessibilitySettings(req.body)));
router.get("/shortcuts/:keyCombo", ok((req) => ({ action: accessibility.resolveShortcut(req.params.keyCombo) })));
router.get("/quick-actions/:context", ok((req) => accessibility.getQuickActions(req.params.context)));

module.exports = router;
