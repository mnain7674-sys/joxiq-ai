const express = require("express");
const router = express.Router();

const phase1Routes = require("./phase1Routes");
const phase2Routes = require("./phase2Routes");

router.use("/", phase1Routes);
router.use("/", phase2Routes);

module.exports = router;
