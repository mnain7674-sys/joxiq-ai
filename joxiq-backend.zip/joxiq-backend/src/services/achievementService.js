const { read, write } = require("../utils/db");
const { getProgressSummary } = require("./planningTrackingService");

/** #70, #71 Auto Achievement System + Badge Generator */
const BADGE_RULES = [
  { id: "first_unit", label: "First Steps", check: (s) => s.unitsCompleted >= 1 },
  { id: "ten_units", label: "Dedicated Learner", check: (s) => s.unitsCompleted >= 10 },
  { id: "fifty_units", label: "Master Learner", check: (s) => s.unitsCompleted >= 50 },
  { id: "high_scorer", label: "High Scorer", check: (s) => s.averageScore >= 90 },
];
function evaluateAchievements(userId) {
  const summary = getProgressSummary(userId);
  const earned = BADGE_RULES.filter((b) => b.check(summary));
  const all = read("badges");
  const existingIds = all.filter((b) => b.userId === userId).map((b) => b.badgeId);
  const newlyEarned = earned.filter((b) => !existingIds.includes(b.id));
  newlyEarned.forEach((b) => all.push({ userId, badgeId: b.id, label: b.label, earnedAt: new Date().toISOString() }));
  if (newlyEarned.length) write("badges", all);
  return { allBadges: earned.map((b) => ({ id: b.id, label: b.label })), newlyEarned: newlyEarned.map((b) => b.id) };
}

/** #72 Auto Learning Recommendations — suggests next topics based on categories the user hasn't touched yet. */
function recommendNextTopics(userId, allTopics) {
  const completed = read("progress").filter((p) => p.userId === userId).map((p) => p.unitId);
  return allTopics.filter((t) => !completed.includes(t.id)).slice(0, 5);
}

module.exports = { evaluateAchievements, recommendNextTopics };
