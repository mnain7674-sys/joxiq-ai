const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

/** #67 Auto Study Planner — spaces topics out across available sessions. */
function buildStudyPlan(userId, topics, { sessionsPerWeek = 3, startDate = new Date() } = {}) {
  const plan = topics.map((topic, i) => {
    const dayOffset = Math.floor(i / sessionsPerWeek) * 7 + (i % sessionsPerWeek) * Math.floor(7 / sessionsPerWeek);
    const date = new Date(startDate);
    date.setDate(date.getDate() + dayOffset);
    return { topic, scheduledFor: date.toISOString().slice(0, 10) };
  });
  const all = read("study_plans");
  const record = { id: randomUUID(), userId, plan, createdAt: new Date().toISOString() };
  all.push(record);
  write("study_plans", all);
  return record;
}

/** #68 Auto Habit Tracker — streak tracking for any recurring habit. */
function logHabitCheckIn(userId, habitId) {
  const all = read("habits");
  let habit = all.find((h) => h.userId === userId && h.habitId === habitId);
  const today = new Date().toISOString().slice(0, 10);
  if (!habit) { habit = { userId, habitId, checkIns: [], streak: 0 }; all.push(habit); }
  if (!habit.checkIns.includes(today)) {
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
    habit.streak = habit.checkIns.includes(yesterday) ? habit.streak + 1 : 1;
    habit.checkIns.push(today);
  }
  write("habits", all);
  return { habitId, streak: habit.streak, totalCheckIns: habit.checkIns.length };
}

/** #69 Auto Progress Tracker */
function recordProgress(userId, unitId, score) {
  const all = read("progress");
  all.push({ userId, unitId, score, completedAt: new Date().toISOString() });
  write("progress", all);
  return getProgressSummary(userId);
}
function getProgressSummary(userId) {
  const entries = read("progress").filter((p) => p.userId === userId);
  const avgScore = entries.length ? entries.reduce((s, e) => s + e.score, 0) / entries.length : 0;
  return { userId, unitsCompleted: entries.length, averageScore: Number(avgScore.toFixed(2)) };
}

module.exports = { buildStudyPlan, logHabitCheckIn, recordProgress, getProgressSummary };
