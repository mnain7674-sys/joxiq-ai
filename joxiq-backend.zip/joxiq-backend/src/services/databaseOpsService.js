const fs = require("fs");
const path = require("path");
const { read, write } = require("../utils/db");

const DATA_DIR = path.join(__dirname, "..", "..", "data");
const BACKUP_DIR = path.join(__dirname, "..", "..", "data-backups");

/** #79 Auto Database Cleaner — removes soft-deleted / expired records across collections. */
function cleanCollection(collectionName, { deletedField = "deleted", maxAgeDays } = {}) {
  const data = read(collectionName);
  let kept = data.filter((r) => !r[deletedField]);
  if (maxAgeDays) {
    const cutoff = Date.now() - maxAgeDays * 24 * 60 * 60 * 1000;
    kept = kept.filter((r) => !r.createdAt || new Date(r.createdAt).getTime() >= cutoff);
  }
  write(collectionName, kept);
  return { removed: data.length - kept.length, remaining: kept.length };
}

/** #80 Auto Database Backup — copies all local JSON data files into a timestamped backup folder. */
function backupDatabase() {
  if (!fs.existsSync(DATA_DIR)) return { filesBackedUp: 0 };
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const dest = path.join(BACKUP_DIR, stamp);
  fs.mkdirSync(dest, { recursive: true });
  const files = fs.readdirSync(DATA_DIR);
  files.forEach((f) => fs.copyFileSync(path.join(DATA_DIR, f), path.join(dest, f)));
  return { filesBackedUp: files.length, backupPath: dest };
}
function listBackups() {
  if (!fs.existsSync(BACKUP_DIR)) return [];
  return fs.readdirSync(BACKUP_DIR).sort().reverse();
}

module.exports = { cleanCollection, backupDatabase, listBackups };
