const { read, write } = require("../utils/db");

/** #92 Auto AI Model Selector — routes a request to the best-fit provider by task type (your existing Gemini/ChatGPT/Claude connections). */
const MODEL_ROUTING = {
  simple_qa: { provider: "gemini", model: "gemini-flash" },
  translation: { provider: "gemini", model: "gemini-flash" },
  complex_reasoning: { provider: "claude", model: "claude-sonnet" },
  creative_writing: { provider: "chatgpt", model: "gpt-4o" },
};
function selectModel(taskType) {
  return MODEL_ROUTING[taskType] || MODEL_ROUTING.simple_qa;
}

/** #93 Auto Token Usage Monitor */
function logTokenUsage(userId, { provider, inputTokens, outputTokens }) {
  const all = read("token_usage");
  const entry = { userId, provider, inputTokens, outputTokens, totalTokens: inputTokens + outputTokens, timestamp: new Date().toISOString() };
  all.push(entry);
  write("token_usage", all);
  return entry;
}
function getTokenUsageSummary(userId) {
  const entries = read("token_usage").filter((e) => e.userId === userId);
  return { totalTokens: entries.reduce((s, e) => s + e.totalTokens, 0), callCount: entries.length };
}

/** #94 Auto Performance Optimizer — flags slow-performing endpoints from recorded latency samples. */
function recordEndpointLatency(endpoint, latencyMs) {
  const all = read("endpoint_latency");
  all.push({ endpoint, latencyMs, recordedAt: new Date().toISOString() });
  if (all.length > 10000) all.splice(0, all.length - 10000);
  write("endpoint_latency", all);
}
function getSlowEndpoints(thresholdMs = 500) {
  const all = read("endpoint_latency");
  const byEndpoint = {};
  all.forEach((e) => { byEndpoint[e.endpoint] = byEndpoint[e.endpoint] || []; byEndpoint[e.endpoint].push(e.latencyMs); });
  return Object.entries(byEndpoint)
    .map(([endpoint, times]) => ({ endpoint, avgMs: Math.round(times.reduce((a, b) => a + b, 0) / times.length) }))
    .filter((e) => e.avgMs > thresholdMs);
}

/** #95 Auto Resource Manager — tracks per-user resource consumption against a plan quota. */
function checkQuota(userId, quotaLimit) {
  const usage = getTokenUsageSummary(userId);
  return { withinQuota: usage.totalTokens <= quotaLimit, used: usage.totalTokens, limit: quotaLimit, remaining: Math.max(0, quotaLimit - usage.totalTokens) };
}

module.exports = { selectModel, logTokenUsage, getTokenUsageSummary, recordEndpointLatency, getSlowEndpoints, checkQuota };
