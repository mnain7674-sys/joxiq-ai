const { read, write } = require("../utils/db");

/** #26 Auto Chat Categorization — keyword-based tagging. */
const CATEGORY_KEYWORDS = {
  language_learning: ["grammar", "vocabulary", "translate", "pronunciation"],
  homework_help: ["homework", "assignment", "exam", "quiz"],
  general_qa: [],
};
function categorizeConversation(text) {
  const lower = text.toLowerCase();
  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    if (keywords.some((k) => lower.includes(k))) return category;
  }
  return "general_qa";
}

/** #27 Auto Chat Folder Creation — auto-assigns a conversation to a folder by category. */
function assignToFolder(userId, conversationId, category) {
  const all = read("chat_folders");
  let folder = all.find((f) => f.userId === userId && f.category === category);
  if (!folder) { folder = { userId, category, conversationIds: [] }; all.push(folder); }
  if (!folder.conversationIds.includes(conversationId)) folder.conversationIds.push(conversationId);
  write("chat_folders", all);
  return folder;
}
function getFolders(userId) {
  return read("chat_folders").filter((f) => f.userId === userId);
}

/** #28 Auto Duplicate Chat Detection — flags conversations with near-identical opening messages. */
function findDuplicates(conversations) {
  const seen = new Map();
  const duplicates = [];
  for (const c of conversations) {
    const key = (c.firstMessage || "").trim().toLowerCase().slice(0, 100);
    if (!key) continue;
    if (seen.has(key)) duplicates.push({ original: seen.get(key), duplicate: c.id });
    else seen.set(key, c.id);
  }
  return duplicates;
}

/** #30 Auto Recent Activity — feed of a user's most recent actions across the app. */
function logActivity(userId, action, details = {}) {
  const all = read("recent_activity");
  all.push({ userId, action, details, at: new Date().toISOString() });
  if (all.length > 10000) all.splice(0, all.length - 10000);
  write("recent_activity", all);
}
function getRecentActivity(userId, limit = 20) {
  return read("recent_activity").filter((a) => a.userId === userId).slice(-limit).reverse();
}

module.exports = { categorizeConversation, assignToFolder, getFolders, findDuplicates, logActivity, getRecentActivity };
