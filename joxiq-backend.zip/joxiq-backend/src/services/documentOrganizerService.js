const { read, write } = require("../utils/db");

/** #53 Auto Document Organizer — categorizes an uploaded document by extension + records metadata. */
const CATEGORY_BY_EXT = {
  pdf: "documents", doc: "documents", docx: "documents", txt: "documents",
  jpg: "images", jpeg: "images", png: "images", gif: "images",
  mp3: "audio", wav: "audio",
  mp4: "video", mov: "video",
};
function organizeDocument(userId, fileName, sizeBytes) {
  const ext = fileName.split(".").pop().toLowerCase();
  const category = CATEGORY_BY_EXT[ext] || "other";
  const all = read("documents");
  const record = { userId, fileName, sizeBytes, category, organizedAt: new Date().toISOString() };
  all.push(record);
  write("documents", all);
  return record;
}
function getDocumentsByCategory(userId, category) {
  return read("documents").filter((d) => d.userId === userId && (!category || d.category === category));
}

/** #58 Auto File Sorter — groups a batch of file names into their target category folders. */
function sortFiles(fileNames) {
  const sorted = {};
  fileNames.forEach((f) => {
    const ext = f.split(".").pop().toLowerCase();
    const category = CATEGORY_BY_EXT[ext] || "other";
    sorted[category] = sorted[category] || [];
    sorted[category].push(f);
  });
  return sorted;
}

/** #59 Auto File Renamer — generates a clean, collision-free file name. */
function renameFile(originalName, { prefix = "", pattern = "{name}_{n}" } = {}) {
  const dot = originalName.lastIndexOf(".");
  const base = dot > 0 ? originalName.slice(0, dot) : originalName;
  const ext = dot > 0 ? originalName.slice(dot) : "";
  const cleanBase = base.replace(/[^a-zA-Z0-9_-]+/g, "_");
  return `${prefix}${cleanBase}${ext}`;
}

/** #60 Auto Screenshot Organizer — detects likely screenshots by filename pattern and groups by date. */
const SCREENSHOT_PATTERN = /screenshot|screen[\s_-]?shot|Capture/i;
function organizeScreenshots(files) {
  // files: [{ name, takenAt }]
  const screenshots = files.filter((f) => SCREENSHOT_PATTERN.test(f.name));
  const byDate = {};
  screenshots.forEach((f) => {
    const date = (f.takenAt || new Date().toISOString()).slice(0, 10);
    byDate[date] = byDate[date] || [];
    byDate[date].push(f.name);
  });
  return byDate;
}

module.exports = { organizeDocument, getDocumentsByCategory, sortFiles, renameFile, organizeScreenshots };
