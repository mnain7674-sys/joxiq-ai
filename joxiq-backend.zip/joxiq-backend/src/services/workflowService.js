const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

/** #51 Auto Workflow Builder — define + save a reusable multi-step workflow. */
function saveWorkflow(userId, name, steps) {
  const all = read("workflows");
  const filtered = all.filter((w) => !(w.userId === userId && w.name === name));
  const workflow = { id: randomUUID(), userId, name, steps, createdAt: new Date().toISOString() };
  filtered.push(workflow);
  write("workflows", filtered);
  return workflow;
}
function getWorkflow(userId, name) {
  return read("workflows").find((w) => w.userId === userId && w.name === name) || null;
}

/** #52 Auto AI Task Runner — executes a saved workflow's steps in order, using caller-supplied step handlers. */
async function runWorkflow(userId, name, stepHandlers) {
  const workflow = getWorkflow(userId, name);
  if (!workflow) throw new Error(`Workflow not found: ${name}`);
  const trace = [];
  let output = null;
  for (const step of workflow.steps) {
    const handler = stepHandlers[step.type];
    if (typeof handler !== "function") { trace.push({ step: step.type, status: "no_handler" }); break; }
    output = await handler(step.params, output);
    trace.push({ step: step.type, status: "completed" });
  }
  const runs = read("workflow_runs");
  const run = { id: randomUUID(), userId, workflowName: name, trace, finalOutput: output, ranAt: new Date().toISOString() };
  runs.push(run);
  write("workflow_runs", runs);
  return run;
}

module.exports = { saveWorkflow, getWorkflow, runWorkflow };
