const { read, write } = require("../utils/db");

/** #96 Auto System Diagnostics — aggregates recent errors/crashes/health checks into one report. */
function runDiagnostics() {
  const errors = read("error_log").slice(-20);
  const healthChecks = read("health_checks").slice(-20);
  const failedChecks = healthChecks.filter((h) => !h.up);
  return {
    recentErrorCount: errors.length,
    recentHealthChecks: healthChecks.length,
    failedHealthChecks: failedChecks.length,
    generatedAt: new Date().toISOString(),
  };
}

/** #97 Auto Maintenance Mode — toggles a system-wide maintenance flag other endpoints can check. */
function setMaintenanceMode(enabled, message = "System under maintenance, back soon.") {
  write("maintenance_mode", [{ enabled, message, updatedAt: new Date().toISOString() }]);
  return { enabled, message };
}
function getMaintenanceMode() {
  const state = read("maintenance_mode")[0];
  return state || { enabled: false, message: null };
}

/** #98 Auto Recovery Manager — restores the most recent database backup (pairs with databaseOpsService.backupDatabase). */
function recoverFromLatestBackup() {
  const fs = require("fs");
  const path = require("path");
  const BACKUP_DIR = path.join(__dirname, "..", "..", "data-backups");
  const DATA_DIR = path.join(__dirname, "..", "..", "data");
  if (!fs.existsSync(BACKUP_DIR)) return { recovered: false, reason: "no backups found" };
  const backups = fs.readdirSync(BACKUP_DIR).sort().reverse();
  if (!backups.length) return { recovered: false, reason: "no backups found" };
  const latest = path.join(BACKUP_DIR, backups[0]);
  const files = fs.readdirSync(latest);
  fs.mkdirSync(DATA_DIR, { recursive: true });
  files.forEach((f) => fs.copyFileSync(path.join(latest, f), path.join(DATA_DIR, f)));
  return { recovered: true, fromBackup: backups[0], filesRestored: files.length };
}

module.exports = { runDiagnostics, setMaintenanceMode, getMaintenanceMode, recoverFromLatestBackup };
