const { read, write } = require("../utils/db");

/** #16 Auto Usage Tracker */
function trackUsage(userId, eventName, metadata = {}) {
  const all = read("usage_events");
  all.push({ userId, eventName, metadata, timestamp: new Date().toISOString() });
  write("usage_events", all);
}

function summarizeRange(userId, start, end) {
  const events = read("usage_events").filter((e) => {
    const t = new Date(e.timestamp);
    return e.userId === userId && t >= start && t < end;
  });
  const byEvent = {};
  events.forEach((e) => (byEvent[e.eventName] = (byEvent[e.eventName] || 0) + 1));
  return { rangeStart: start.toISOString(), rangeEnd: end.toISOString(), totalEvents: events.length, eventBreakdown: byEvent };
}

/** #17 Auto Daily Statistics */
function getDailyStats(userId, dateStr) {
  const target = dateStr ? new Date(dateStr) : new Date();
  const start = new Date(target); start.setHours(0, 0, 0, 0);
  const end = new Date(start); end.setDate(end.getDate() + 1);
  return summarizeRange(userId, start, end);
}

/** #18 Auto Weekly Report */
function getWeeklyStats(userId, weekStartStr) {
  const start = weekStartStr ? new Date(weekStartStr) : (() => {
    const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - d.getDay()); return d;
  })();
  const end = new Date(start); end.setDate(end.getDate() + 7);
  return summarizeRange(userId, start, end);
}

/** #19 Auto Monthly Report */
function getMonthlyStats(userId, year, month) {
  const now = new Date();
  const y = year || now.getFullYear();
  const m = month !== undefined ? month : now.getMonth();
  return summarizeRange(userId, new Date(y, m, 1), new Date(y, m + 1, 1));
}

module.exports = { trackUsage, getDailyStats, getWeeklyStats, getMonthlyStats };
