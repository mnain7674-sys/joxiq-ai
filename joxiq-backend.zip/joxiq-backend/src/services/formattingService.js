/** #40 Auto Response Formatter — cleans up whitespace/line breaks in AI output before display. */
function formatResponse(text) {
  return text
    .replace(/\r\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .replace(/[ \t]+$/gm, "")
    .trim();
}

/** #41 Auto Markdown Formatter — ensures consistent markdown (heading spacing, list markers). */
function formatMarkdown(text) {
  return text
    .replace(/^(#{1,6})([^\s#])/gm, "$1 $2") // ensure space after #
    .replace(/^[-*]\s*/gm, "- ") // normalize bullet markers
    .replace(/\n{3,}/g, "\n\n");
}

/** #42 Auto Code Formatter — normalizes indentation (spaces) in a code block; language-agnostic basic pass. */
function formatCode(code, indentSize = 2) {
  const lines = code.split("\n");
  let depth = 0;
  return lines.map((line) => {
    const trimmed = line.trim();
    if (/^[}\])]/.test(trimmed)) depth = Math.max(0, depth - 1);
    const formatted = " ".repeat(depth * indentSize) + trimmed;
    if (/[{[(]\s*$/.test(trimmed)) depth += 1;
    return formatted;
  }).join("\n");
}

module.exports = { formatResponse, formatMarkdown, formatCode };
