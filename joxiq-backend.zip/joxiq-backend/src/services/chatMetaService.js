const { read, write } = require("../utils/db");

/** #3 Auto Chat Title Generator — derives a short title from the first user message (no LLM needed). */
function generateTitle(firstMessage) {
  if (!firstMessage) return "New Chat";
  const cleaned = firstMessage.trim().replace(/\s+/g, " ");
  const words = cleaned.split(" ").slice(0, 6).join(" ");
  return words.length < cleaned.length ? `${words}...` : words;
}

/** #4 Auto Prompt History — logs every prompt a user sends, for recall/reuse. */
function logPrompt(userId, promptText) {
  const all = read("prompt_history");
  all.push({ userId, promptText, sentAt: new Date().toISOString() });
  write("prompt_history", all);
}
function getPromptHistory(userId, limit = 50) {
  return read("prompt_history").filter((p) => p.userId === userId).slice(-limit).reverse();
}

/** #5 Auto Favorite Chats — toggles a conversation as favorited. */
function toggleFavorite(userId, conversationId) {
  const all = read("favorites");
  const idx = all.findIndex((f) => f.userId === userId && f.conversationId === conversationId);
  if (idx >= 0) {
    all.splice(idx, 1);
    write("favorites", all);
    return { favorited: false };
  }
  all.push({ userId, conversationId, favoritedAt: new Date().toISOString() });
  write("favorites", all);
  return { favorited: true };
}
function getFavorites(userId) {
  return read("favorites").filter((f) => f.userId === userId);
}

module.exports = { generateTitle, logPrompt, getPromptHistory, toggleFavorite, getFavorites };
