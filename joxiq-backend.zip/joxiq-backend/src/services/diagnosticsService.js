const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

/** #14 Auto Error Logger */
function logError(context, error) {
  const all = read("error_log");
  const entry = { id: randomUUID(), context, message: error.message || String(error), stack: error.stack || null, loggedAt: new Date().toISOString() };
  all.push(entry);
  write("error_log", all);
  return entry;
}

/** #15 Auto Bug Reporter — structured report a user can submit, separate from silent error logs. */
function submitBugReport(userId, { description, stepsToReproduce, screenshotUrl }) {
  const all = read("bug_reports");
  const report = { id: randomUUID(), userId, description, stepsToReproduce, screenshotUrl, status: "open", submittedAt: new Date().toISOString() };
  all.push(report);
  write("bug_reports", all);
  return report;
}

/** #37 Auto Loading Optimizer — records load-time samples per screen and recommends a threshold flag. */
function recordLoadTime(screenName, loadMs) {
  const all = read("load_times");
  all.push({ screenName, loadMs, recordedAt: new Date().toISOString() });
  if (all.length > 5000) all.splice(0, all.length - 5000);
  write("load_times", all);
}
function getSlowScreens(thresholdMs = 1000) {
  const all = read("load_times");
  const byScreen = {};
  all.forEach((e) => {
    byScreen[e.screenName] = byScreen[e.screenName] || [];
    byScreen[e.screenName].push(e.loadMs);
  });
  return Object.entries(byScreen)
    .map(([screenName, times]) => ({ screenName, avgLoadMs: Math.round(times.reduce((a, b) => a + b, 0) / times.length) }))
    .filter((s) => s.avgLoadMs > thresholdMs);
}

/** #39 Auto App Performance Monitor — generic metric recorder (memory, FPS, CPU, etc). */
function recordPerformanceMetric(metric, value) {
  const all = read("performance_metrics");
  all.push({ metric, value, recordedAt: new Date().toISOString() });
  if (all.length > 5000) all.splice(0, all.length - 5000);
  write("performance_metrics", all);
}
function getPerformanceSummary(metric) {
  const entries = read("performance_metrics").filter((e) => !metric || e.metric === metric);
  return entries.slice(-100);
}

module.exports = { logError, submitBugReport, recordLoadTime, getSlowScreens, recordPerformanceMetric, getPerformanceSummary };
