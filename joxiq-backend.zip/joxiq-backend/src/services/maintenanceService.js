const fs = require("fs");
const path = require("path");
const { read, write } = require("../utils/db");

const DATA_DIR = path.join(__dirname, "..", "..", "data");

/** #12 Auto Cache Cleaner — sweeps expired cache entries. */
function addCacheEntry(key, value, ttlMs = 7 * 24 * 60 * 60 * 1000) {
  const all = read("cache").filter((e) => e.key !== key);
  all.push({ key, value, expiresAt: new Date(Date.now() + ttlMs).toISOString() });
  write("cache", all);
}
function getCacheEntry(key) {
  const entry = read("cache").find((e) => e.key === key);
  if (!entry || new Date(entry.expiresAt) < new Date()) return null;
  return entry.value;
}
function cleanExpiredCache() {
  const all = read("cache");
  const kept = all.filter((e) => new Date(e.expiresAt) >= new Date());
  write("cache", kept);
  return { removed: all.length - kept.length, remaining: kept.length };
}

/** #13 Auto Storage Optimizer — reports disk usage of local data files and trims oversized collections. */
function getStorageReport() {
  if (!fs.existsSync(DATA_DIR)) return { totalBytes: 0, files: [] };
  const files = fs.readdirSync(DATA_DIR).map((f) => ({ file: f, bytes: fs.statSync(path.join(DATA_DIR, f)).size }));
  return { totalBytes: files.reduce((s, f) => s + f.bytes, 0), files };
}
function optimizeCollection(collectionName, keep = 1000) {
  const data = read(collectionName);
  if (!Array.isArray(data) || data.length <= keep) return { trimmed: 0 };
  write(collectionName, data.slice(-keep));
  return { trimmed: data.length - keep, remaining: keep };
}

/** #38 Auto Memory Cleanup — clears expired in-memory-style records (drafts, session state older than N days). */
function cleanupStaleRecords(collectionName, dateField, maxAgeDays = 30) {
  const data = read(collectionName);
  const cutoff = Date.now() - maxAgeDays * 24 * 60 * 60 * 1000;
  const kept = data.filter((r) => new Date(r[dateField] || 0).getTime() >= cutoff);
  write(collectionName, kept);
  return { removed: data.length - kept.length, remaining: kept.length };
}

module.exports = { addCacheEntry, getCacheEntry, cleanExpiredCache, getStorageReport, optimizeCollection, cleanupStaleRecords };
