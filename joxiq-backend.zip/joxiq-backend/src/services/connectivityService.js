const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

/** #33 Auto Device Detection — parses a user-agent string into device info (no external lib needed). */
function detectDevice(userAgent = "") {
  const isMobile = /Mobile|Android|iPhone/i.test(userAgent);
  const isTablet = /Tablet|iPad/i.test(userAgent);
  const os = /Android/i.test(userAgent) ? "Android"
    : /iPhone|iPad|iOS/i.test(userAgent) ? "iOS"
    : /Windows/i.test(userAgent) ? "Windows"
    : /Mac/i.test(userAgent) ? "macOS"
    : /Linux/i.test(userAgent) ? "Linux" : "Unknown";
  return { deviceType: isTablet ? "tablet" : isMobile ? "mobile" : "desktop", os };
}

/** #34, #35 Auto Offline/Internet Detection — server-side records client-reported connectivity pings. */
function recordConnectivityPing(userId, isOnline) {
  const all = read("connectivity_log");
  all.push({ userId, isOnline, pingedAt: new Date().toISOString() });
  if (all.length > 5000) all.splice(0, all.length - 5000);
  write("connectivity_log", all);
}
function getConnectivityStatus(userId) {
  const entries = read("connectivity_log").filter((e) => e.userId === userId);
  const latest = entries[entries.length - 1];
  return latest ? { isOnline: latest.isOnline, lastPingAt: latest.pingedAt } : { isOnline: null, lastPingAt: null };
}

/** #36 Auto Sync Queue — queues actions taken while offline, to replay once back online. */
function queueOfflineAction(userId, action, payload) {
  const all = read("sync_queue");
  const item = { id: randomUUID(), userId, action, payload, status: "pending", queuedAt: new Date().toISOString() };
  all.push(item);
  write("sync_queue", all);
  return item;
}
function getPendingSyncItems(userId) {
  return read("sync_queue").filter((i) => i.userId === userId && i.status === "pending");
}
function markSynced(itemId) {
  const all = read("sync_queue");
  const item = all.find((i) => i.id === itemId);
  if (item) { item.status = "synced"; item.syncedAt = new Date().toISOString(); write("sync_queue", all); }
  return item;
}

module.exports = { detectDevice, recordConnectivityPing, getConnectivityStatus, queueOfflineAction, getPendingSyncItems, markSynced };
