const { read, write } = require("../utils/db");

/** #88 Auto Feature Toggle */
function setFlag(flagName, enabled, rolloutPercent = 100) {
  const all = read("feature_flags");
  let flag = all.find((f) => f.flagName === flagName);
  if (!flag) { flag = { flagName }; all.push(flag); }
  flag.enabled = enabled;
  flag.rolloutPercent = rolloutPercent;
  flag.updatedAt = new Date().toISOString();
  write("feature_flags", all);
  return flag;
}
function isFlagEnabled(flagName, userId = "") {
  const flag = read("feature_flags").find((f) => f.flagName === flagName);
  if (!flag || !flag.enabled) return false;
  if (flag.rolloutPercent >= 100) return true;
  const hash = [...String(userId)].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 100, 0);
  return hash < flag.rolloutPercent;
}

/** #89 Auto Feedback Collector */
const POSITIVE_WORDS = ["love", "great", "helpful", "amazing", "easy"];
const NEGATIVE_WORDS = ["hate", "bad", "confusing", "broken", "slow"];
function collectFeedback(userId, text) {
  const lower = text.toLowerCase();
  const posHits = POSITIVE_WORDS.filter((w) => lower.includes(w)).length;
  const negHits = NEGATIVE_WORDS.filter((w) => lower.includes(w)).length;
  const sentiment = posHits > negHits ? "positive" : negHits > posHits ? "negative" : "neutral";
  const all = read("feedback");
  const entry = { userId, text, sentiment, submittedAt: new Date().toISOString() };
  all.push(entry);
  write("feedback", all);
  return entry;
}
function getFeedbackTrends() {
  const all = read("feedback");
  const counts = { positive: 0, neutral: 0, negative: 0 };
  all.forEach((f) => counts[f.sentiment]++);
  return counts;
}

module.exports = { setFlag, isFlagEnabled, collectFeedback, getFeedbackTrends };
