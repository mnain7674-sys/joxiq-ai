/**
 * #54 Auto PDF Analyzer
 * Uses `pdf-parse` (free, open source, no API key) to extract text + metadata.
 * npm install pdf-parse
 */
async function analyzePdf(pdfBuffer) {
  const pdfParse = require("pdf-parse");
  const data = await pdfParse(pdfBuffer);
  return {
    pageCount: data.numpages,
    textPreview: data.text.slice(0, 500),
    wordCount: data.text.split(/\s+/).filter(Boolean).length,
    info: data.info,
  };
}

/**
 * #55 Auto Image Analyzer
 * Uses `jimp` (free, open source, pure JS, no API key) for basic image
 * stats. For semantic content understanding (what's *in* the image),
 * that requires a real vision model — not included here to stay 100% free.
 */
async function analyzeImage(imageBuffer) {
  const Jimp = require("jimp");
  const image = await Jimp.read(imageBuffer);
  return {
    width: image.getWidth(),
    height: image.getHeight(),
    format: image.getMIME(),
    aspectRatio: Number((image.getWidth() / image.getHeight()).toFixed(2)),
  };
}

/**
 * #56 Auto OCR Scanner
 * Uses `tesseract.js` (free, open source, runs fully offline/locally, no API key).
 * npm install tesseract.js
 */
async function scanOcr(imageBuffer) {
  const Tesseract = require("tesseract.js");
  const { data } = await Tesseract.recognize(imageBuffer, "eng");
  return { text: data.text, confidence: data.confidence };
}

/**
 * #57 Auto QR Scanner
 * Uses `jsqr` + `jimp` (both free, open source, no API key) to decode QR codes locally.
 * npm install jsqr jimp
 */
async function scanQrCode(imageBuffer) {
  const Jimp = require("jimp");
  const jsQR = require("jsqr");
  const image = await Jimp.read(imageBuffer);
  const { data, width, height } = image.bitmap;
  const result = jsQR(new Uint8ClampedArray(data), width, height);
  return result ? { found: true, data: result.data } : { found: false };
}

module.exports = { analyzePdf, analyzeImage, scanOcr, scanQrCode };
