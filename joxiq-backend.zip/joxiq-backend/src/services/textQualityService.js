/**
 * #43 Auto Text Correction — fixes common typos using a small built-in map
 * (fully offline, no paid API). Extend COMMON_TYPOS as needed.
 */
const COMMON_TYPOS = {
  teh: "the", recieve: "receive", definately: "definitely", occured: "occurred",
  seperate: "separate", untill: "until", wich: "which", becuase: "because",
  alot: "a lot", thier: "their", ur: "your", u: "you",
};
function correctText(text) {
  return text.replace(/\b[\w']+\b/g, (word) => {
    const lower = word.toLowerCase();
    if (COMMON_TYPOS[lower]) {
      const fix = COMMON_TYPOS[lower];
      return word[0] === word[0].toUpperCase() ? fix[0].toUpperCase() + fix.slice(1) : fix;
    }
    return word;
  });
}

/** #44 Auto Spelling Check — flags words not in a small known-word list (demo-scale; swap in a full free dictionary like `hunspell` for production). */
const KNOWN_EXTRA_WORDS = new Set(); // populate with a real free word list (e.g. an English word list file) for production use
function checkSpelling(text) {
  const flagged = [];
  const words = text.match(/\b[a-zA-Z']+\b/g) || [];
  words.forEach((w) => {
    if (COMMON_TYPOS[w.toLowerCase()]) flagged.push({ word: w, suggestion: COMMON_TYPOS[w.toLowerCase()] });
  });
  return flagged;
}

/** #45 Auto Grammar Check — rule-based checks for common grammar issues (double spaces, repeated words, etc). */
function checkGrammar(text) {
  const issues = [];
  if (/\b(\w+)\s+\1\b/i.test(text)) issues.push({ type: "repeated_word", message: "A word appears to be repeated" });
  if (/\s{2,}/.test(text)) issues.push({ type: "spacing", message: "Multiple consecutive spaces found" });
  if (/\bi\b/.test(text)) issues.push({ type: "capitalization", message: "'i' should be capitalized as 'I'" });
  if (/[a-z]\.[A-Z]/.test(text)) issues.push({ type: "spacing", message: "Missing space after a period" });
  return issues;
}

/**
 * #46 Auto Translation — offline demo dictionary for a handful of common phrases.
 * For real multi-language translation with no cost, self-host LibreTranslate
 * (open source, free) and pass its call in as translateFn; this function will
 * use that if provided, otherwise falls back to the built-in mini dictionary.
 */
const MINI_DICTIONARY = {
  en_bn: { hello: "হ্যালো", "thank you": "ধন্যবাদ", yes: "হ্যাঁ", no: "না" },
  bn_en: { "হ্যালো": "hello", "ধন্যবাদ": "thank you", "হ্যাঁ": "yes", "না": "no" },
};
async function translate(text, fromLang, toLang, translateFn) {
  if (typeof translateFn === "function") return translateFn(text, fromLang, toLang);
  const dict = MINI_DICTIONARY[`${fromLang}_${toLang}`];
  const lower = text.trim().toLowerCase();
  if (dict && dict[lower]) return { text: dict[lower], source: "builtin_dictionary" };
  return { text, source: "untranslated", note: "No free translation provider configured — self-host LibreTranslate and pass translateFn to enable full translation" };
}

module.exports = { correctText, checkSpelling, checkGrammar, translate };
