const { read } = require("../utils/db");

/** #90 Auto Analytics Dashboard — rolls up key platform metrics. */
function getAnalyticsDashboard() {
  const users = new Set(read("usage_events").map((e) => e.userId));
  const conversations = read("conversations");
  const feedback = read("feedback");
  return {
    activeUsers: users.size,
    totalConversations: conversations.length,
    totalFeedback: feedback.length,
    generatedAt: new Date().toISOString(),
  };
}

/** #91 Auto User Activity Monitor — flags users who have gone quiet (churn risk signal). */
function getInactiveUsers(allUserIds, inactiveDays = 14) {
  const cutoff = Date.now() - inactiveDays * 24 * 60 * 60 * 1000;
  const events = read("usage_events");
  const lastActive = {};
  events.forEach((e) => {
    const t = new Date(e.timestamp).getTime();
    if (!lastActive[e.userId] || t > lastActive[e.userId]) lastActive[e.userId] = t;
  });
  return allUserIds.filter((id) => !lastActive[id] || lastActive[id] < cutoff);
}

module.exports = { getAnalyticsDashboard, getInactiveUsers };
