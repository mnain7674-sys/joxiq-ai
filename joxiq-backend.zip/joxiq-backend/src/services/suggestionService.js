const { read, write } = require("../utils/db");

/** #24 Auto AI Suggestions — recommends next actions based on the user's recent activity pattern. */
function suggestNextActions(userId) {
  const events = require("./usageStatsService");
  const daily = events.getDailyStats(userId);
  const suggestions = [];
  if (!daily.eventBreakdown.chat_sent) suggestions.push("Start a new conversation");
  if (!daily.eventBreakdown.quiz_taken) suggestions.push("Take a quick quiz to test your progress");
  if (daily.totalEvents === 0) suggestions.push("Welcome back! Pick up where you left off");
  return suggestions;
}

/** #25 Auto Prompt Suggestions — curated starter prompts, optionally filtered by topic. */
const PROMPT_LIBRARY = [
  { topic: "language", prompt: "Correct my grammar in this sentence: ..." },
  { topic: "language", prompt: "Explain the difference between these two words: ..." },
  { topic: "study", prompt: "Quiz me on this topic: ..." },
  { topic: "study", prompt: "Summarize this chapter in 5 bullet points." },
  { topic: "general", prompt: "Explain this like I'm a beginner: ..." },
];
function suggestPrompts(topic) {
  return topic ? PROMPT_LIBRARY.filter((p) => p.topic === topic) : PROMPT_LIBRARY;
}

/** #29 Auto Search Suggestions — prefix match against a user's own search history. */
function recordSearch(userId, query) {
  const all = read("search_history");
  all.push({ userId, query, searchedAt: new Date().toISOString() });
  write("search_history", all);
}
function getSearchSuggestions(userId, partialQuery) {
  const history = read("search_history").filter((h) => h.userId === userId).map((h) => h.query);
  const unique = [...new Set(history)];
  const q = partialQuery.toLowerCase();
  return unique.filter((s) => s.toLowerCase().includes(q)).slice(0, 8);
}

module.exports = { suggestNextActions, suggestPrompts, recordSearch, getSearchSuggestions };
