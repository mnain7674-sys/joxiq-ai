const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

/** #81 Auto Security Scanner — checks basic request/text patterns for common injection attempts (free, rule-based). */
const SUSPICIOUS_PATTERNS = [/<script/i, /(\bor\b\s+1=1)/i, /union\s+select/i, /\.\.\//, /javascript:/i];
function scanForThreats(input) {
  const hits = SUSPICIOUS_PATTERNS.filter((p) => p.test(input));
  return { safe: hits.length === 0, matchedPatterns: hits.length };
}

/** #82 Auto Login Protection — tracks failed attempts and locks out after a threshold. */
function recordLoginAttempt(userId, success) {
  const all = read("login_attempts");
  all.push({ userId, success, attemptedAt: new Date().toISOString() });
  write("login_attempts", all);
}
function isLockedOut(userId, { maxFailures = 5, windowMs = 15 * 60 * 1000 } = {}) {
  const cutoff = Date.now() - windowMs;
  const recent = read("login_attempts").filter((a) => a.userId === userId && new Date(a.attemptedAt).getTime() >= cutoff);
  const failures = recent.filter((a) => !a.success).length;
  return { lockedOut: failures >= maxFailures, failures };
}

/** #83 Auto Spam Detection — heuristic scoring, free/rule-based. */
function scoreSpam(text) {
  let score = 0;
  if ((text.match(/https?:\/\//g) || []).length > 2) score += 0.4;
  if (/\b(buy now|click here|free money|guaranteed)\b/i.test(text)) score += 0.4;
  if (text.length > 20 && text === text.toUpperCase()) score += 0.2;
  return Math.min(score, 1);
}

/** #84 Auto Content Filter — flags content for review based on spam/security scores. */
function filterContent(userId, text) {
  const spam = scoreSpam(text);
  const threat = scanForThreats(text);
  if (spam > 0.6 || !threat.safe) {
    const all = read("content_flags");
    const flag = { id: randomUUID(), userId, text, spam, threatDetected: !threat.safe, flaggedAt: new Date().toISOString() };
    all.push(flag);
    write("content_flags", all);
    return { allowed: false, reason: !threat.safe ? "security" : "spam" };
  }
  return { allowed: true };
}

module.exports = { scanForThreats, recordLoginAttempt, isLockedOut, scoreSpam, filterContent };
