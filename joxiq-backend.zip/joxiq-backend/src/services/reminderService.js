const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

/** #23 Auto Notification Scheduler — the core scheduler the other 3 reminder types build on. */
function scheduleNotification(userId, { title, body, sendAt, category = "general" }) {
  const all = read("notifications");
  const entry = { id: randomUUID(), userId, title, body, sendAt, category, status: "pending", createdAt: new Date().toISOString() };
  all.push(entry);
  write("notifications", all);
  return entry;
}
function getDueNotifications() {
  const all = read("notifications");
  const now = new Date();
  const due = all.filter((n) => n.status === "pending" && new Date(n.sendAt) <= now);
  due.forEach((n) => (n.status = "sent"));
  write("notifications", all);
  return due;
}

/** #20 Auto Goal Reminder */
function setGoalReminder(userId, goalName, cadenceHours = 24) {
  return scheduleNotification(userId, {
    title: "Goal check-in", body: `Time to work on: ${goalName}`,
    sendAt: new Date(Date.now() + cadenceHours * 3600 * 1000).toISOString(), category: "goal",
  });
}

/** #21 Auto Study Reminder */
function setStudyReminder(userId, topic, sendAt) {
  return scheduleNotification(userId, { title: "Study time!", body: `Continue learning: ${topic}`, sendAt, category: "study" });
}

/** #22 Auto Task Reminder */
function setTaskReminder(userId, taskName, dueAt) {
  return scheduleNotification(userId, { title: "Task due soon", body: taskName, sendAt: dueAt, category: "task" });
}

module.exports = { scheduleNotification, getDueNotifications, setGoalReminder, setStudyReminder, setTaskReminder };
