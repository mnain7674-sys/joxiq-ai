const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

function requireGenerator(generateFn) {
  if (typeof generateFn !== "function") {
    throw new Error("Pass generateFn(prompt) wrapping your existing Gemini/ChatGPT/Claude call");
  }
}

/** #63 Auto Quiz Generator */
async function generateQuiz(sourceText, generateFn, questionCount = 5) {
  requireGenerator(generateFn);
  const raw = await generateFn(
    `Create ${questionCount} quiz questions with answers from this text, as a JSON array of {question, answer}:\n\n${sourceText}`
  );
  const all = read("quizzes");
  const quiz = { id: randomUUID(), raw, createdAt: new Date().toISOString() };
  all.push(quiz);
  write("quizzes", all);
  return quiz;
}

/** #64 Auto Exam Generator */
async function generateExam(sourceText, generateFn, questionCount = 20) {
  requireGenerator(generateFn);
  const raw = await generateFn(
    `Create a ${questionCount}-question exam (mix of multiple-choice and short answer) from this text:\n\n${sourceText}`
  );
  const all = read("exams");
  const exam = { id: randomUUID(), raw, createdAt: new Date().toISOString() };
  all.push(exam);
  write("exams", all);
  return exam;
}

/** #65 Auto Flashcard Generator */
async function generateFlashcards(sourceText, generateFn, cardCount = 10) {
  requireGenerator(generateFn);
  const raw = await generateFn(
    `Create ${cardCount} flashcards (front/back pairs) from this text, as a JSON array of {front, back}:\n\n${sourceText}`
  );
  const all = read("flashcards");
  const set = { id: randomUUID(), raw, createdAt: new Date().toISOString() };
  all.push(set);
  write("flashcards", all);
  return set;
}

/** #66 Auto Mind Map Generator */
async function generateMindMap(sourceText, generateFn) {
  requireGenerator(generateFn);
  const raw = await generateFn(
    `Create a hierarchical mind map (as nested JSON: {topic, children: [...]}) summarizing this text:\n\n${sourceText}`
  );
  const all = read("mind_maps");
  const map = { id: randomUUID(), raw, createdAt: new Date().toISOString() };
  all.push(map);
  write("mind_maps", all);
  return map;
}

module.exports = { generateQuiz, generateExam, generateFlashcards, generateMindMap };
