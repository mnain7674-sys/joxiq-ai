const { read, write } = require("../utils/db");

/** #77 Auto API Monitor — counts calls per API key/endpoint. */
function recordApiCall(apiKey, endpoint) {
  const all = read("api_usage");
  all.push({ apiKey, endpoint, calledAt: new Date().toISOString() });
  if (all.length > 20000) all.splice(0, all.length - 20000);
  write("api_usage", all);
}
function getApiUsage(apiKey, sinceMs = 3600_000) {
  const cutoff = Date.now() - sinceMs;
  return read("api_usage").filter((e) => e.apiKey === apiKey && new Date(e.calledAt).getTime() >= cutoff).length;
}

/** #78 Auto Server Health Check — pings a URL using Node's built-in fetch (free, no library needed). */
async function checkServerStatus(name, url) {
  const start = Date.now();
  const all = read("health_checks");
  try {
    const res = await fetch(url, { method: "GET" });
    const latencyMs = Date.now() - start;
    const result = { name, up: res.ok, statusCode: res.status, latencyMs, checkedAt: new Date().toISOString() };
    all.push(result);
    write("health_checks", all);
    return result;
  } catch (e) {
    const result = { name, up: false, error: e.message, checkedAt: new Date().toISOString() };
    all.push(result);
    write("health_checks", all);
    return result;
  }
}
function getHealthHistory(name) {
  return read("health_checks").filter((h) => h.name === name).slice(-50);
}

module.exports = { recordApiCall, getApiUsage, checkServerStatus, getHealthHistory };
