const { read, write } = require("../utils/db");

/** #75 Auto Search Indexing — builds a simple inverted word index over a collection for fast lookup. */
function buildIndex(collectionName, textField) {
  const items = read(collectionName);
  const index = {};
  items.forEach((item, i) => {
    const text = (item[textField] || "").toLowerCase();
    const words = new Set(text.match(/\b[a-z0-9]+\b/g) || []);
    words.forEach((w) => {
      index[w] = index[w] || [];
      index[w].push(i);
    });
  });
  write(`${collectionName}_index`, [{ index, builtAt: new Date().toISOString() }]);
  return { indexedTerms: Object.keys(index).length, itemCount: items.length };
}
function searchIndex(collectionName, query) {
  const stored = read(`${collectionName}_index`)[0];
  if (!stored) return [];
  const items = read(collectionName);
  const words = query.toLowerCase().match(/\b[a-z0-9]+\b/g) || [];
  const matchedIndexes = new Set();
  words.forEach((w) => (stored.index[w] || []).forEach((i) => matchedIndexes.add(i)));
  return [...matchedIndexes].map((i) => items[i]).filter(Boolean);
}

/** #76 Auto Data Validation — validates a record against a simple field-rule schema. */
function validate(record, schema) {
  const errors = [];
  for (const [field, rule] of Object.entries(schema)) {
    const value = record[field];
    if (rule.required && (value === undefined || value === null || value === "")) {
      errors.push({ field, message: "is required" });
      continue;
    }
    if (value === undefined) continue;
    if (rule.type && typeof value !== rule.type) errors.push({ field, message: `should be ${rule.type}` });
    if (rule.minLength && String(value).length < rule.minLength) errors.push({ field, message: `must be at least ${rule.minLength} characters` });
    if (rule.pattern && !new RegExp(rule.pattern).test(value)) errors.push({ field, message: "has invalid format" });
  }
  return { valid: errors.length === 0, errors };
}

module.exports = { buildIndex, searchIndex, validate };
