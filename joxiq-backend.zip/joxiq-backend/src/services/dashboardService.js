const { read, write } = require("../utils/db");

/** #73 Auto Smart Dashboard — reorders dashboard widgets by usage frequency. */
function personalizeDashboard(userId, widgetIds) {
  const events = read("usage_events").filter((e) => e.userId === userId && e.eventName === "widget_view");
  const counts = {};
  events.forEach((e) => { const w = e.metadata?.widgetId; if (w) counts[w] = (counts[w] || 0) + 1; });
  return [...widgetIds].sort((a, b) => (counts[b] || 0) - (counts[a] || 0));
}

/** #74 Auto Widget Manager — enable/disable/reorder widgets per user. */
function setWidgetConfig(userId, widgetId, config) {
  const all = read("widget_config");
  let entry = all.find((w) => w.userId === userId && w.widgetId === widgetId);
  if (!entry) { entry = { userId, widgetId }; all.push(entry); }
  Object.assign(entry, config);
  write("widget_config", all);
  return entry;
}
function getWidgetConfigs(userId) {
  return read("widget_config").filter((w) => w.userId === userId);
}

module.exports = { personalizeDashboard, setWidgetConfig, getWidgetConfigs };
