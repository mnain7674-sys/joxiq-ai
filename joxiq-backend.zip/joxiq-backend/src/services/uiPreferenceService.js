const { read, write } = require("../utils/db");

/** #8 Auto Theme Detection — suggests dark/light theme by local hour (or client-passed hour). */
function detectTheme(hour = new Date().getHours()) {
  return hour >= 19 || hour < 6 ? "dark" : "light";
}

/** #9 Auto Language Detection — script-based heuristic, no external API needed. */
function detectLanguage(text) {
  const patterns = {
    bn: /[\u0980-\u09FF]/, ar: /[\u0600-\u06FF]/, hi: /[\u0900-\u097F]/, zh: /[\u4E00-\u9FFF]/,
  };
  for (const [lang, re] of Object.entries(patterns)) if (re.test(text)) return lang;
  return "en";
}

/** #10 Auto Greeting Message — time-of-day + returning-user aware greeting. */
function getGreeting(userName, hour = new Date().getHours()) {
  let timeGreeting = "Hello";
  if (hour < 12) timeGreeting = "Good morning";
  else if (hour < 18) timeGreeting = "Good afternoon";
  else timeGreeting = "Good evening";
  return userName ? `${timeGreeting}, ${userName}!` : `${timeGreeting}!`;
}

/** #31 Auto User Preferences — generic key/value preference store. */
function setPreference(userId, key, value) {
  const all = read("preferences");
  let p = all.find((x) => x.userId === userId);
  if (!p) { p = { userId, values: {} }; all.push(p); }
  p.values[key] = value;
  write("preferences", all);
  return p.values;
}
function getPreferences(userId) {
  return (read("preferences").find((p) => p.userId === userId) || { values: {} }).values;
}

/** #32 Auto Settings Backup — snapshots the full preference set. */
function backupSettings(userId) {
  const prefs = getPreferences(userId);
  const all = read("settings_backups");
  all.push({ userId, prefs, backedUpAt: new Date().toISOString() });
  write("settings_backups", all);
  return { backedUp: true, keys: Object.keys(prefs).length };
}
function restoreSettings(userId) {
  const backups = read("settings_backups").filter((b) => b.userId === userId);
  backups.sort((a, b) => new Date(b.backedUpAt) - new Date(a.backedUpAt));
  const latest = backups[0];
  if (!latest) return null;
  const all = read("preferences");
  let p = all.find((x) => x.userId === userId);
  if (!p) { p = { userId, values: {} }; all.push(p); }
  p.values = latest.prefs;
  write("preferences", all);
  return p.values;
}

module.exports = { detectTheme, detectLanguage, getGreeting, setPreference, getPreferences, backupSettings, restoreSettings };
