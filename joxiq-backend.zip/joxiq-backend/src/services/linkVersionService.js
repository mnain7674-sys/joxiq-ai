/**
 * #85 Auto Link Checker — uses Node's built-in fetch (free) to verify a URL responds.
 */
async function checkLink(url) {
  try {
    const res = await fetch(url, { method: "HEAD" });
    return { url, working: res.ok, statusCode: res.status };
  } catch (e) {
    return { url, working: false, error: e.message };
  }
}
async function checkLinks(urls) {
  return Promise.all(urls.map(checkLink));
}

/** #86 Auto Version Checker — semver-style comparison, no dependency needed. */
function compareVersions(v1, v2) {
  const parse = (v) => v.split(".").map(Number);
  const [a1, a2, a3] = parse(v1);
  const [b1, b2, b3] = parse(v2);
  if (a1 !== b1) return a1 - b1;
  if (a2 !== b2) return a2 - b2;
  return (a3 || 0) - (b3 || 0);
}

/** #87 Auto Update Checker — flags whether a newer version is available. */
function checkForUpdate(currentVersion, latestVersion) {
  const cmp = compareVersions(currentVersion, latestVersion);
  return { currentVersion, latestVersion, updateAvailable: cmp < 0 };
}

module.exports = { checkLink, checkLinks, compareVersions, checkForUpdate };
