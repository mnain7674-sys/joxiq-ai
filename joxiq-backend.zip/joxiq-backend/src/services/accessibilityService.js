/** #47 Auto Voice Detection — flags whether client-reported audio input had detectable speech (energy-based heuristic; actual VAD runs client-side). */
function detectVoiceActivity(audioEnergyLevels) {
  // audioEnergyLevels: array of numbers (e.g. RMS values sampled client-side)
  if (!audioEnergyLevels.length) return { speechDetected: false };
  const avg = audioEnergyLevels.reduce((a, b) => a + b, 0) / audioEnergyLevels.length;
  return { speechDetected: avg > 0.02, averageEnergy: Number(avg.toFixed(4)) };
}

/** #48 Auto Accessibility Mode — derives recommended accessibility settings from user-reported needs. */
function getAccessibilitySettings({ prefersLargeText, prefersHighContrast, prefersReducedMotion, usesScreenReader } = {}) {
  return {
    fontSizeScale: prefersLargeText ? 1.3 : 1.0,
    theme: prefersHighContrast ? "high-contrast" : "default",
    animationsEnabled: !prefersReducedMotion,
    ariaVerbose: !!usesScreenReader,
  };
}

/** #49 Auto Keyboard Shortcut Detection — maps a key combo string to an app action. */
const SHORTCUTS = {
  "ctrl+k": "open_search",
  "ctrl+n": "new_chat",
  "ctrl+/": "show_shortcuts",
  "ctrl+shift+d": "toggle_theme",
  "esc": "close_dialog",
};
function resolveShortcut(keyCombo) {
  return SHORTCUTS[keyCombo.toLowerCase()] || null;
}

/** #50 Auto Quick Actions — surfaces a small context-aware action menu. */
function getQuickActions(context) {
  const actions = [];
  if (context === "conversation") actions.push("Copy last response", "Regenerate", "New chat", "Favorite");
  if (context === "settings") actions.push("Reset to defaults", "Export data");
  if (context === "dashboard") actions.push("View progress", "Start quiz");
  return actions;
}

module.exports = { detectVoiceActivity, getAccessibilitySettings, resolveShortcut, getQuickActions };
