const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

/**
 * #61 Auto Notes Generator
 * #62 Auto Summary Generator
 * These use your app's existing Gemini/ChatGPT/Claude connection (which
 * JOXIQ AI already pays for as its core product) — no *new* paid API is
 * introduced here. Pass in generateFn(prompt) wrapping whichever provider
 * call you already use elsewhere in the app.
 */
async function generateNotes(sourceText, generateFn) {
  if (typeof generateFn !== "function") {
    throw new Error("Pass generateFn(prompt) wrapping your existing Gemini/ChatGPT/Claude call");
  }
  const notes = await generateFn(`Turn the following into concise bullet-point notes:\n\n${sourceText}`);
  const all = read("notes");
  const record = { id: randomUUID(), notes, createdAt: new Date().toISOString() };
  all.push(record);
  write("notes", all);
  return record;
}

async function generateSummary(sourceText, generateFn, maxSentences = 3) {
  if (typeof generateFn !== "function") {
    throw new Error("Pass generateFn(prompt) wrapping your existing Gemini/ChatGPT/Claude call");
  }
  const summary = await generateFn(`Summarize the following in ${maxSentences} sentences or fewer:\n\n${sourceText}`);
  return { summary };
}

module.exports = { generateNotes, generateSummary };
