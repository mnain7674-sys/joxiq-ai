const { randomUUID } = require("crypto");
const { read, write } = require("../utils/db");

/** #1 Auto Chat Save — persists a message the instant it's sent. */
function saveMessage(userId, conversationId, message) {
  const all = read("conversations");
  let convo = all.find((c) => c.id === conversationId && c.userId === userId);
  if (!convo) {
    convo = { id: conversationId || randomUUID(), userId, createdAt: new Date().toISOString(), messages: [] };
    all.push(convo);
  }
  convo.messages.push({ id: randomUUID(), role: message.role, content: message.content, savedAt: new Date().toISOString() });
  convo.updatedAt = new Date().toISOString();
  write("conversations", all);
  return convo;
}
function getConversation(userId, conversationId) {
  return read("conversations").find((c) => c.id === conversationId && c.userId === userId) || null;
}

/** #2 Auto Conversation Recovery — recovers an in-progress (unsaved) draft after a crash/close. */
function saveDraft(userId, conversationId, draftText) {
  const all = read("drafts");
  const filtered = all.filter((d) => !(d.userId === userId && d.conversationId === conversationId));
  filtered.push({ userId, conversationId, draftText, savedAt: new Date().toISOString() });
  write("drafts", filtered);
}
function recoverDraft(userId, conversationId) {
  return read("drafts").find((d) => d.userId === userId && d.conversationId === conversationId) || null;
}

/** #6 Auto Chat Backup — snapshots all of a user's conversations. */
function backupChats(userId) {
  const conversations = read("conversations").filter((c) => c.userId === userId);
  const all = read("chat_backups");
  const backup = { id: randomUUID(), userId, conversations, createdAt: new Date().toISOString() };
  all.push(backup);
  write("chat_backups", all);
  return { id: backup.id, createdAt: backup.createdAt, conversationCount: conversations.length };
}

/** #7 Auto Chat Restore — restores the most recent backup for a user. */
function restoreChats(userId) {
  const backups = read("chat_backups").filter((b) => b.userId === userId);
  backups.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const latest = backups[0];
  if (!latest) return { restored: 0 };

  const all = read("conversations").filter((c) => c.userId !== userId);
  write("conversations", [...all, ...latest.conversations]);
  return { restored: latest.conversations.length, fromBackup: latest.id };
}

/** #11 Auto Session Restore — snapshots + recovers active session state (open conversation, scroll pos, etc). */
function saveSessionState(userId, state) {
  const all = read("session_state");
  const filtered = all.filter((s) => s.userId !== userId);
  filtered.push({ userId, state, savedAt: new Date().toISOString() });
  write("session_state", filtered);
}
function restoreSessionState(userId) {
  return read("session_state").find((s) => s.userId === userId) || null;
}

module.exports = {
  saveMessage, getConversation, saveDraft, recoverDraft,
  backupChats, restoreChats, saveSessionState, restoreSessionState,
};
