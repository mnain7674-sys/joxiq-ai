const { read } = require("../utils/db");
const systemOps = require("./systemOpsService");
const modelOps = require("./modelOpsService");
const featureFeedback = require("./featureFeedbackService");
const analyticsDashboard = require("./analyticsDashboardService");

/** #99 Auto Automation Center — status overview of every automated job/flag/queue in the system. */
function getAutomationCenterStatus() {
  const flags = read("feature_flags");
  const workflows = read("workflows");
  const workflowRuns = read("workflow_runs").slice(-10);
  const maintenance = systemOps.getMaintenanceMode();
  return {
    generatedAt: new Date().toISOString(),
    maintenanceMode: maintenance,
    activeFlags: flags.filter((f) => f.enabled).map((f) => f.flagName),
    savedWorkflows: workflows.length,
    recentWorkflowRuns: workflowRuns.length,
  };
}

/** #100 Auto AI Control Center — the single top-level dashboard tying together health, usage, and business signals. */
function getControlCenterDashboard() {
  return {
    generatedAt: new Date().toISOString(),
    diagnostics: systemOps.runDiagnostics(),
    analytics: analyticsDashboard.getAnalyticsDashboard(),
    automation: getAutomationCenterStatus(),
    feedbackTrends: featureFeedback.getFeedbackTrends(),
  };
}

module.exports = { getAutomationCenterStatus, getControlCenterDashboard };
